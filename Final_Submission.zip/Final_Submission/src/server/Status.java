package server;

public enum Status {
    IDLE,
    BUSY,
    CONNECTING
}
